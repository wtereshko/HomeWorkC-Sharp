﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Serelization
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person("Petro", 22);
            Person person2 = new Person("Olenka", 25);
            Person person3 = new Person("Oksana", 25);
            Person[] persons = new Person[] { person, person2, person3 };
            BinnaryFormatter(person);
            SoapFormatter(persons);
            XMLFormatter(person2);
            //JSONFormatter(persons);

            Console.WriteLine("Об'єкт створено");
        }

        private static void BinnaryFormatter(Person person)
        {
            // create instance BinaryFormatter
            BinaryFormatter formatter = new BinaryFormatter();
            

            using (FileStream fs = new FileStream("BinaryFormatter.txt", FileMode.OpenOrCreate)) {
                //Serialization
                formatter.Serialize(fs, person);

                Console.WriteLine("Об'єкт серiалiзованo");
            }

            // Deserialization
            using (FileStream fs = new FileStream("BinaryFormatter.txt", FileMode.OpenOrCreate)) {
                Person newPerson = (Person) formatter.Deserialize(fs);

                Console.WriteLine("Об'єкт десерiалiзованo");
                Console.WriteLine("Name: {0} -*- Age: {1}", newPerson.Name, newPerson.Age);
            }

            Console.ReadKey();
        }


        private static void SoapFormatter(Person[] persons)
        {
            // create instance SoapFormatter
            SoapFormatter formatter = new SoapFormatter();
            
            using (FileStream fs = new FileStream("SoapFormatter.soap", FileMode.OpenOrCreate)) {
                //Serialization
                formatter.Serialize(fs, persons);

                Console.WriteLine("Об'єкт серiалiзованo");
            }

            // Deserialization
            using (FileStream fs = new FileStream("SoapFormatter.soap", FileMode.OpenOrCreate)) {
                Person[] newPeople = (Person[]) formatter.Deserialize(fs);

                Console.WriteLine("Об'єкт десерiалiзованo");
                foreach (Person p in newPeople) {
                    Console.WriteLine("Name: {0} -*- Age: {1}", p.Name, p.Age);
                }
            }

            Console.ReadKey();
        }

        private static void XMLFormatter(Person person)
        {
            // create instance XmlSerializer and add type 
            XmlSerializer formatter = new XmlSerializer(typeof(Person));

            using (FileStream fs = new FileStream("XMLFormatter.xml", FileMode.OpenOrCreate))
            {
                //Serialization
                formatter.Serialize(fs, person);

                Console.WriteLine("Об'єкт серiалiзованo");
            }

            // Deserialization
            using (FileStream fs = new FileStream("XMLFormatter.xml", FileMode.OpenOrCreate))
            {
                Person newPerson = (Person)formatter.Deserialize(fs);

                Console.WriteLine("Об'єкт десерiалiзованo");
                Console.WriteLine("Name: {0} -*- Age: {1}", newPerson.Name, newPerson.Age);
            }

            Console.ReadKey();
        }
        private static void JSONFormatter(Person[] persons)
        {
           // create instance JSONSerializer and add type
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Person[]));

            using (FileStream fs = new FileStream("JSONFormatter.json", FileMode.OpenOrCreate))
            {
               // Serialization
                jsonFormatter.WriteObject(fs, persons);
            }

            using (FileStream fs = new FileStream("JSONFormatter.json", FileMode.OpenOrCreate))
            {
                //Deserialization
                Person[] newpeople = (Person[])jsonFormatter.ReadObject(fs);

                foreach (Person p in newpeople)
                {
                    Console.WriteLine("Name: {0} -*- Age: {1}", p.Name, p.Age);
                }
            }

            Console.ReadKey();
        }
    }


    //[DataContract]
    [Serializable]
    public class Person
    {
        //[DataMember]
        public string Name { get; set; }
        // [DataMember]
        public int Age { get; set; }

        public Person() { }

        public Person(string name, int age)
        {
            Name = name;
            Age = age;
        }
    }
}


